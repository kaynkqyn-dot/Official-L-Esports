import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "L¹ Esports — Tournament Platform",
  description: "L¹ Esports tournament registration, brackets and results.",
  applicationName: "L¹ Esports",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "L¹ Esports" }
};
export const viewport: Viewport = {
  themeColor: "#08090b",
  width: "device-width",
  initialScale: 1
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="mn"><body>{children}</body></html>;
}
