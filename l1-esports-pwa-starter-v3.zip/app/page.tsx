import Link from "next/link";
import { Trophy, ShieldCheck, Users, Swords, ArrowUpRight } from "lucide-react";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  let tournaments: any[] = [];
  let dbReady = false;
  try {
    const supabase = await createClient();
    const { data, error } = await supabase.from("tournaments")
      .select("id,title,title_en,game,format,status,start_at,slots_total,slots_filled")
      .in("status", ["registration", "live", "completed"])
      .order("created_at", { ascending: false }).limit(6);
    if (!error) { tournaments = data ?? []; dbReady = true; }
  } catch {}
  return (
    <main>
      <header style={{borderBottom:"1px solid #24252a", background:"rgba(8,9,11,.82)", position:"sticky", top:0, zIndex:5, backdropFilter:"blur(14px)"}}>
        <div className="shell" style={{height:72,display:"flex",alignItems:"center",justifyContent:"space-between",gap:16}}>
          <Link href="/" style={{display:"flex",alignItems:"center",gap:10}}>
            <div style={{width:42,height:42,border:"1px solid #b88b39",borderRadius:12,display:"grid",placeItems:"center",background:"#17130b"}} className="brand gold">L¹</div>
            <div><div className="brand" style={{fontSize:23,lineHeight:1}}>L¹ ESPORTS</div><div style={{fontSize:9,letterSpacing:".22em",color:"#a8a398"}}>COMPETE WITH PURPOSE</div></div>
          </Link>
          <nav style={{display:"flex",alignItems:"center",gap:20}}>
            <a className="navlink" href="#tournaments">Тэмцээн / Events</a>
            <Link className="navlink" href="/dashboard">Dashboard</Link>
            <Link className="btn" href="/login">Нэвтрэх / Sign in</Link>
          </nav>
        </div>
      </header>
      <section className="shell" style={{padding:"68px 0 54px"}}>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,340px),1fr))",gap:36,alignItems:"center"}}>
          <div>
            <div className="eyebrow" style={{display:"flex",alignItems:"center",gap:9}}><span style={{display:"inline-block",width:24,height:1,background:"#d7ad55"}}/> MONGOLIAN ESPORTS PLATFORM</div>
            <h1 className="brand" style={{fontSize:"clamp(3.5rem,9vw,6.8rem)",lineHeight:.9,margin:"22px 0"}}>PLAY<br/><span className="gold">BEYOND</span><br/>LIMITS.</h1>
            <p className="muted" style={{maxWidth:510,lineHeight:1.8}}>Тэмцээнээ бүртгүүл. Багийнхаа хүчийг харуул. Үр дүнгээ нэг дороос хяна.<br/>Register. Compete. Track every result in one place.</p>
            <div style={{display:"flex",gap:12,flexWrap:"wrap",marginTop:26}}>
              <a className="btn" href="#tournaments">Тэмцээн үзэх <ArrowUpRight size={17} style={{marginLeft:8}}/></a>
              <Link className="btn-secondary" href="/login">Admin / Player access</Link>
            </div>
            <p style={{fontSize:12,color:"#77756f",marginTop:22}}>MONGOLIAN / ENGLISH · MOBILE-FIRST · PWA READY</p>
          </div>
          <div className="panel" style={{padding:24,position:"relative",overflow:"hidden",minHeight:310}}>
            <div style={{position:"absolute",width:230,height:230,borderRadius:"50%",border:"1px solid #5d4824",right:-65,top:-80}}/>
            <div style={{position:"absolute",width:160,height:160,borderRadius:"50%",border:"1px solid #5d4824",right:-30,top:-45}}/>
            <div className="eyebrow">PLATFORM OVERVIEW</div>
            <div className="brand gold" style={{fontSize:64,margin:"22px 0 12px"}}>L¹</div>
            <div style={{fontSize:22,fontWeight:800}}>One platform. Every match.</div>
            <p className="muted" style={{lineHeight:1.7}}>Tournament registration, verified teams, match brackets and official results — built for competitive play.</p>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10,marginTop:24}}>
              {[["01","REGISTER"],["02","COMPETE"],["03","RISE UP"]].map(([n,label])=><div key={n} style={{padding:"13px 10px",background:"#0b0c0e",border:"1px solid #2b2c30",borderRadius:10}}><div className="gold brand" style={{fontSize:22}}>{n}</div><div style={{fontSize:10,letterSpacing:".08em",marginTop:4}}>{label}</div></div>)}
            </div>
          </div>
        </div>
      </section>
      <section id="tournaments" style={{borderTop:"1px solid #222328",borderBottom:"1px solid #222328",background:"rgba(15,16,19,.75)",padding:"48px 0"}}>
        <div className="shell">
          <div style={{display:"flex",justifyContent:"space-between",gap:18,alignItems:"end",flexWrap:"wrap",marginBottom:22}}>
            <div><div className="eyebrow">COMPETE HERE</div><h2 className="brand" style={{fontSize:38,margin:"8px 0 0"}}>TOURNAMENTS <span className="gold">/ ТЭМЦЭЭН</span></h2></div>
            <div className="muted" style={{fontSize:13}}>{dbReady ? "Live database connected" : "Database setup required"}</div>
          </div>
          {!dbReady && <div className="panel" style={{padding:22,marginBottom:18}}><div style={{display:"flex",gap:12,alignItems:"start"}}><ShieldCheck className="gold" size={24}/><div><b>Database connection is not configured yet.</b><p className="muted" style={{marginBottom:0,lineHeight:1.6}}>Follow SETUP.md to connect your private Supabase project. Tournament cards will load from the database after setup.</p></div></div></div>}
          {dbReady && tournaments.length === 0 && <div className="panel" style={{padding:24}}><p className="muted">Одоогоор тэмцээн алга. / No tournaments published yet.</p></div>}
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,260px),1fr))",gap:14}}>
            {tournaments.map((t:any)=><article className="panel" key={t.id} style={{padding:20}}>
              <div style={{display:"flex",justifyContent:"space-between",gap:10}}><span className="eyebrow">{t.game}</span><span style={{fontSize:11,color:"#d9b968",border:"1px solid #5c4824",borderRadius:20,padding:"4px 8px"}}>{t.status}</span></div>
              <h3 className="brand" style={{fontSize:25,margin:"16px 0 8px"}}>{t.title}</h3><p className="muted" style={{fontSize:13}}>{t.format} · {t.slots_filled}/{t.slots_total} teams</p>
              <div style={{height:4,background:"#292a2e",borderRadius:10,overflow:"hidden"}}><div style={{height:"100%",width:`${Math.min(100,(t.slots_filled/Math.max(1,t.slots_total))*100)}%`,background:"linear-gradient(90deg,#9d7228,#f2d58b)"}}/></div>
            </article>)}
          </div>
        </div>
      </section>
      <section className="shell" style={{padding:"42px 0 58px",display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,210px),1fr))",gap:14}}>
        {[[Trophy,"Tournament brackets","Тэмцээний хүснэгт"],[Users,"Team registration","Багийн бүртгэл"],[Swords,"Match results","Тоглолтын үр дүн"],[ShieldCheck,"Secure admin","Хамгаалалттай удирдлага"]].map(([Icon,title,sub]:any)=><div className="panel" key={title} style={{padding:20}}><Icon className="gold" size={24}/><h3 style={{fontSize:16,margin:"16px 0 6px"}}>{title}</h3><p className="muted" style={{fontSize:13,margin:0}}>{sub}</p></div>)}
      </section>
      <footer style={{borderTop:"1px solid #24252a",padding:"22px 0",color:"#77756f",fontSize:12}}><div className="shell" style={{display:"flex",justifyContent:"space-between",gap:12,flexWrap:"wrap"}}><span>© {new Date().getFullYear()} L¹ Esports</span><span>Built for competition. Designed for mobile.</span></div></footer>
    </main>
  );
}
