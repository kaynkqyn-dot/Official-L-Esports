import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createTournament, updateRegistrationStatus, updateTournamentStatus } from "./actions";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await supabase.from("profiles").select("role").eq("id",user.id).maybeSingle();
  if (!profile || !["organizer","admin","super_admin"].includes(profile.role)) redirect("/dashboard?error=admin-required");
  const { data: tournaments } = await supabase.from("tournaments").select("*").order("created_at",{ascending:false});
  const { data: registrations } = await supabase.from("registrations").select("id,status,created_at,tournaments(title),teams(name,tag),submitted_by").order("created_at",{ascending:false}).limit(100);
  return <main className="shell" style={{padding:"28px 0 64px"}}>
    <header style={{display:"flex",justifyContent:"space-between",gap:12,flexWrap:"wrap"}}><Link href="/" className="brand gold" style={{fontSize:25}}>L¹ ESPORTS</Link><Link href="/dashboard" className="navlink">← Dashboard</Link></header>
    <div className="eyebrow" style={{marginTop:28}}>CONTROL ROOM</div><h1 className="brand" style={{fontSize:46,margin:"8px 0"}}>ADMIN PANEL.</h1>
    <p className="muted" style={{lineHeight:1.7}}>Тэмцээн үүсгэх, бүртгэл шалгах, нийтлэх болон хаах. Зөвхөн эрхтэй хэрэглэгч энэ хуудсанд нэвтэрнэ.</p>
    <section className="panel" style={{padding:22,marginTop:24}}>
      <div className="eyebrow">CREATE EVENT</div><h2 className="brand" style={{fontSize:28,margin:"8px 0"}}>Шинэ тэмцээн нэмэх</h2>
      <form action={createTournament} style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,220px),1fr))",gap:"0 14px"}}>
        <label className="field">Тэмцээний нэр<input name="title" required maxLength={120} placeholder="L¹ WOW 4v4 CUP"/></label>
        <label className="field">English title<input name="title_en" maxLength={120} placeholder="L¹ WOW 4v4 CUP"/></label>
        <label className="field">Тоглоом<input name="game" defaultValue="PUBG MOBILE" required/></label>
        <label className="field">Горим<input name="mode" defaultValue="WOW 4v4" required/></label>
        <label className="field">Формат<select name="format" defaultValue="BO3"><option>BO1</option><option>BO3</option><option>BO5</option></select></label>
        <label className="field">Slot-ийн тоо<input name="slots_total" type="number" min="2" max="256" defaultValue="16" required/></label>
        <label className="field">Бүртгэл хаах<input name="registration_closes_at" type="datetime-local"/></label>
        <label className="field">Эхлэх өдөр, цаг<input name="start_at" type="datetime-local"/></label>
        <label className="field" style={{gridColumn:"1/-1"}}>Тайлбар / Rules<textarea name="description" rows={3} maxLength={3000}/></label>
        <label className="field">Эхний төлөв<select name="status" defaultValue="draft"><option value="draft">Draft — нууц</option><option value="registration">Registration open — нийтлэх</option></select></label>
        <div style={{display:"flex",alignItems:"end",paddingBottom:12}}><button className="btn" type="submit">Тэмцээн үүсгэх / Create</button></div>
      </form>
    </section>
    <section style={{marginTop:28}}><div className="eyebrow">EVENT MANAGEMENT</div><h2 className="brand" style={{fontSize:30}}>ТЭМЦЭЭНҮҮД</h2>
      <div style={{display:"grid",gap:10}}>{(tournaments??[]).map((t:any)=><div className="panel" key={t.id} style={{padding:16,display:"flex",justifyContent:"space-between",alignItems:"center",gap:14,flexWrap:"wrap"}}>
        <div><b>{t.title}</b><div className="muted" style={{fontSize:12,marginTop:5}}>{t.game} · {t.format} · {t.slots_filled}/{t.slots_total} · {t.status}</div></div>
        <div style={{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap"}}><Link className="btn-secondary" href={`/tournaments/${t.id}`}>View</Link>
          <form action={updateTournamentStatus}><input type="hidden" name="id" value={t.id}/><select aria-label="Tournament status" name="status" defaultValue={t.status} style={{background:"#0b0c0e",border:"1px solid #3a3b40",color:"#eee",padding:9,borderRadius:8}}>{["draft","registration","locked","live","completed","cancelled"].map(s=><option key={s}>{s}</option>)}</select><button className="btn-secondary" type="submit">Save</button></form>
        </div>
      </div>)}</div>
    </section>
    <section style={{marginTop:30}}><div className="eyebrow">TEAM ENTRIES</div><h2 className="brand" style={{fontSize:30}}>БАГИЙН БҮРТГЭЛ</h2>
      {!registrations?.length ? <div className="panel" style={{padding:20}}><p className="muted">Бүртгэл ирээгүй байна.</p></div> : <div style={{display:"grid",gap:10}}>{registrations.map((r:any)=><div className="panel" key={r.id} style={{padding:16,display:"flex",justifyContent:"space-between",alignItems:"center",gap:12,flexWrap:"wrap"}}>
        <div><b>{r.teams?.name ?? "Unknown team"}</b> <span className="muted">[{r.teams?.tag}]</span><div className="muted" style={{fontSize:12,marginTop:5}}>{r.tournaments?.title} · {r.status}</div></div>
        <form action={updateRegistrationStatus} style={{display:"flex",gap:8,flexWrap:"wrap"}}><input type="hidden" name="id" value={r.id}/><select name="status" defaultValue={r.status} style={{background:"#0b0c0e",border:"1px solid #3a3b40",color:"#eee",padding:9,borderRadius:8}}><option value="pending">pending</option><option value="approved">approved</option><option value="rejected">rejected</option><option value="withdrawn">withdrawn</option></select><button className="btn-secondary" type="submit">Шинэчлэх</button></form>
      </div>)}</div>}
    </section>
  </main>;
}
