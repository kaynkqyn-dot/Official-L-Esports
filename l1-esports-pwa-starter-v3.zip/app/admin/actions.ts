"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";

async function requireStaff() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await supabase.from("profiles").select("role").eq("id",user.id).maybeSingle();
  if (!profile || !["organizer","admin","super_admin"].includes(profile.role)) redirect("/dashboard?error=admin-required");
  return { supabase, user, role: profile.role };
}
export async function createTournament(formData: FormData) {
  const { supabase, user } = await requireStaff();
  const title = String(formData.get("title")||"").trim();
  const title_en = String(formData.get("title_en")||"").trim() || null;
  const game = String(formData.get("game")||"PUBG MOBILE").trim();
  const mode = String(formData.get("mode")||"WOW 4v4").trim();
  const format = String(formData.get("format")||"BO3");
  const slots_total = Number(formData.get("slots_total")||16);
  const status = String(formData.get("status")||"draft");
  const description = String(formData.get("description")||"").trim() || null;
  const toIso = (v: FormDataEntryValue | null) => v ? new Date(String(v)).toISOString() : null;
  if (!title || !Number.isInteger(slots_total) || slots_total < 2 || slots_total > 256 || !["BO1","BO3","BO5"].includes(format) || !["draft","registration"].includes(status)) redirect("/admin?error=invalid-input");
  const { error } = await supabase.from("tournaments").insert({
    title,title_en,game,mode,format,slots_total,slots_filled:0,status,description,
    registration_closes_at:toIso(formData.get("registration_closes_at")),
    start_at:toIso(formData.get("start_at")),created_by:user.id
  });
  if (error) redirect("/admin?error=create-failed");
  revalidatePath("/"); revalidatePath("/tournaments"); revalidatePath("/admin");
  redirect("/admin?created=1");
}
export async function updateTournamentStatus(formData: FormData) {
  const { supabase } = await requireStaff();
  const id = String(formData.get("id")||"");
  const status = String(formData.get("status")||"");
  if (!id || !["draft","registration","locked","live","completed","cancelled"].includes(status)) redirect("/admin?error=invalid-status");
  const { error } = await supabase.from("tournaments").update({status}).eq("id",id);
  if (error) redirect("/admin?error=status-failed");
  revalidatePath("/"); revalidatePath("/tournaments"); revalidatePath(`/tournaments/${id}`); revalidatePath("/admin");
  redirect("/admin?updated=1");
}
export async function updateRegistrationStatus(formData: FormData) {
  const { supabase, user } = await requireStaff();
  const id = String(formData.get("id")||"");
  const status = String(formData.get("status")||"");
  if (!id || !["pending","approved","rejected","withdrawn"].includes(status)) redirect("/admin?error=invalid-registration-status");
  const { error } = await supabase.from("registrations").update({
    status,reviewed_by:user.id,reviewed_at:new Date().toISOString()
  }).eq("id",id);
  if (error) redirect("/admin?error=review-failed");
  revalidatePath("/admin");
  redirect("/admin?reviewed=1");
}
