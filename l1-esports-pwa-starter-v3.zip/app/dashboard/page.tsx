import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { signOut } from "./actions";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  const { data: profile } = await supabase.from("profiles").select("role,display_name").eq("id", user.id).maybeSingle();
  const isAdmin = profile?.role === "admin" || profile?.role === "super_admin";
  const { data: myEntries } = await supabase.from("team_memberships").select("id,team_id,teams(name,tag)").eq("user_id", user.id);
  const { data: tournaments } = isAdmin ? await supabase.from("tournaments").select("id,title,status,slots_filled,slots_total,created_at").order("created_at",{ascending:false}).limit(20) : {data:[] as any[]};
  return <main className="shell" style={{padding:"28px 0 60px"}}>
    <header style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:12,flexWrap:"wrap",marginBottom:28}}>
      <Link href="/" className="brand gold" style={{fontSize:25}}>L¹ ESPORTS</Link>
      <form action={signOut}><button className="btn-secondary">Гарах / Sign out</button></form>
    </header>
    <div className="eyebrow">ACCOUNT DASHBOARD</div>
    <h1 className="brand" style={{fontSize:42,margin:"8px 0"}}>YOUR COMMAND CENTER.</h1>
    <p className="muted">Signed in as {user.email}</p>
    <div className="panel" style={{padding:22,marginTop:22}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:12,flexWrap:"wrap"}}>
        <div><div className="eyebrow">ACCOUNT ROLE</div><h2 style={{margin:"8px 0 0",fontSize:22}}>{isAdmin ? "Administrator" : "Player / Team member"}</h2></div>
        <span style={{border:"1px solid #5d4824",padding:"7px 10px",borderRadius:20,color:"#f2d58b",fontSize:12}}>{profile?.role ?? "player"}</span>
      </div>
      {!isAdmin && <p className="muted" style={{lineHeight:1.7,marginBottom:0}}>Админ эрх автоматаар олгогдохгүй. Эхний super_admin эрхийг Supabase SQL Editor-оос SETUP.md зааврын дагуу гараар олгоно.</p>}
    </div>
    {isAdmin && <section style={{marginTop:24}}>
      <h2 className="brand" style={{fontSize:30}}>TOURNAMENT ADMIN</h2>
      <div className="panel" style={{padding:20,marginBottom:14}}>
        <p className="muted">Admin-ийн эхний хувилбар: database-аас тэмцээнүүдийг уншина. Үүсгэх/засах формыг дараагийн үе шатанд сервер талын validation-тэй холбоно.</p>
        <div style={{fontSize:13,color:"#d9b968"}}>{tournaments?.length ?? 0} tournament records found</div>
      </div>
      <div style={{display:"grid",gap:10}}>
        {(tournaments ?? []).map((t:any)=><div key={t.id} className="panel" style={{padding:16,display:"flex",justifyContent:"space-between",gap:12,flexWrap:"wrap"}}><div><b>{t.title}</b><div className="muted" style={{fontSize:12,marginTop:5}}>{t.status} · {t.slots_filled}/{t.slots_total} teams</div></div><code style={{color:"#d9b968",fontSize:12}}>{t.id.slice(0,8)}</code></div>)}
      </div>
    </section>}
    <section style={{marginTop:24}}>
      <h2 className="brand" style={{fontSize:28}}>MY TEAMS / МИНИЙ БАГУУД</h2>
      {!myEntries?.length ? <div className="panel" style={{padding:18}}><p className="muted" style={{margin:0}}>Таны хэрэглэгчтэй холбогдсон баг одоогоор алга. Баг бүртгэлийн workflow дараагийн алхамд нэмэгдэнэ.</p></div> :
        myEntries.map((m:any)=><div className="panel" key={m.id} style={{padding:16,marginBottom:10}}>{m.teams?.name} <span className="muted">[{m.teams?.tag}]</span></div>)}
    </section>
  </main>;
}
