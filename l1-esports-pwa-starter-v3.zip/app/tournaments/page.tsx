import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

export default async function TournamentsPage() {
  const supabase = await createClient();
  const { data: tournaments, error } = await supabase.from("tournaments")
    .select("id,title,title_en,description,game,mode,format,status,slots_total,slots_filled,registration_closes_at,start_at")
    .in("status", ["registration", "locked", "live", "completed"])
    .order("start_at", { ascending: true, nullsFirst: false });
  return <main className="shell" style={{padding:"30px 0 64px"}}>
    <Link href="/" className="navlink">← L¹ Esports</Link>
    <div className="eyebrow" style={{marginTop:28}}>OFFICIAL COMPETITIONS</div>
    <h1 className="brand" style={{fontSize:48,margin:"8px 0"}}>TOURNAMENTS <span className="gold">/ ТЭМЦЭЭН</span></h1>
    <p className="muted" style={{lineHeight:1.7}}>Тэмцээн сонгоод дэлгэрэнгүй мэдээлэл болон багийн бүртгэлтэй танилцаарай.</p>
    {error ? <div className="panel" style={{padding:20,marginTop:20}}>Database тохиргоо хийгдээгүй байна. SETUP.md зааврыг шалгана уу.</div> : null}
    {!error && !tournaments?.length ? <div className="panel" style={{padding:24,marginTop:20}}><h2 className="brand">NO ACTIVE EVENTS</h2><p className="muted">Одоогоор нийтлэгдсэн тэмцээн алга. Шинэ тэмцээн зарлагдах үед энд харагдана.</p></div> : null}
    <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,290px),1fr))",gap:16,marginTop:22}}>
      {(tournaments ?? []).map((t:any)=>{
        const start = t.start_at ? new Date(t.start_at) : null;
        const close = t.registration_closes_at ? new Date(t.registration_closes_at) : null;
        return <article key={t.id} className="panel" style={{padding:22}}>
          <div style={{display:"flex",justifyContent:"space-between",gap:8,alignItems:"center"}}><span className="eyebrow">{t.game}</span><span style={{fontSize:11,color:"#e7c875",border:"1px solid #5c4824",borderRadius:18,padding:"4px 8px"}}>{t.status.toUpperCase()}</span></div>
          <h2 className="brand" style={{fontSize:29,margin:"16px 0 8px"}}>{t.title}</h2>
          <p className="muted" style={{fontSize:13}}>{t.mode} · {t.format}</p>
          <div style={{borderTop:"1px solid #2b2c30",paddingTop:12,marginTop:15,fontSize:13,lineHeight:1.8}}>
            <div>Эхлэх / Starts: <b>{start ? start.toLocaleString("en-GB",{dateStyle:"medium",timeStyle:"short"}) : "TBA"}</b></div>
            <div>Бүртгэл хаах / Registration closes: <b>{close ? close.toLocaleString("en-GB",{dateStyle:"medium",timeStyle:"short"}) : "TBA"}</b></div>
            <div>Баг / Teams: <b>{t.slots_filled}/{t.slots_total}</b></div>
          </div>
          <div style={{height:5,background:"#2a2b2f",borderRadius:10,overflow:"hidden",margin:"14px 0"}}><div style={{height:"100%",width:`${Math.min(100,t.slots_filled/Math.max(1,t.slots_total)*100)}%`,background:"linear-gradient(90deg,#a77b2b,#f2d58b)"}}/></div>
          <Link href={`/tournaments/${t.id}`} className="btn" style={{width:"100%"}}>Дэлгэрэнгүй / Details →</Link>
        </article>
      })}
    </div>
  </main>;
}
