"use server";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function submitTeamRegistration(formData: FormData) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const tournamentId = String(formData.get("tournament_id") || "");
  if (!user || !tournamentId) redirect("/login");

  const teamName = String(formData.get("team_name") || "").trim();
  const teamTag = String(formData.get("team_tag") || "").trim();
  const captainGameId = String(formData.get("captain_game_id") || "").trim();
  const roster = [1,2,3,4].map(n => ({
    name: String(formData.get(`player_${n}_name`) || "").trim(),
    game_id: String(formData.get(`player_${n}_id`) || "").trim()
  }));
  const notes = String(formData.get("notes") || "").trim();

  if (!teamName || !teamTag || !captainGameId || roster.some(p => !p.name || !p.game_id)) {
    redirect(`/tournaments/${tournamentId}/register?error=missing-fields`);
  }

  const { error } = await supabase.rpc("submit_team_registration", {
    p_tournament_id: tournamentId,
    p_team_name: teamName,
    p_team_tag: teamTag,
    p_captain_game_id: captainGameId,
    p_roster: roster,
    p_notes: notes || null
  });

  if (error) {
    const message = error.message.toLowerCase();
    if (message.includes("tag is already in use")) redirect(`/tournaments/${tournamentId}/register?error=tag-exists`);
    if (message.includes("slot") || message.includes("registration") || message.includes("deadline") || message.includes("already have")) {
      redirect(`/tournaments/${tournamentId}/register?error=registration-closed`);
    }
    redirect(`/tournaments/${tournamentId}/register?error=submit-failed`);
  }

  redirect(`/tournaments/${tournamentId}?registered=1`);
}
