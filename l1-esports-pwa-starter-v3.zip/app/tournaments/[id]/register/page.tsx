import Link from "next/link";
import { redirect, notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { submitTeamRegistration } from "./actions";

export const dynamic = "force-dynamic";

export default async function RegisterTeamPage({ params, searchParams }: { params: { id: string }; searchParams?: { error?: string } }) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/login?next=/tournaments/${params.id}/register`);
  const { data: tournament } = await supabase.from("tournaments").select("id,title,status,slots_total,slots_filled,registration_closes_at").eq("id",params.id).maybeSingle();
  if (!tournament) notFound();
  const closed = tournament.status !== "registration" || tournament.slots_filled >= tournament.slots_total || (tournament.registration_closes_at && new Date(tournament.registration_closes_at).getTime() <= Date.now());
  if (closed) return <main className="shell" style={{padding:"40px 0"}}><div className="panel" style={{maxWidth:620,margin:"auto",padding:24}}><h1 className="brand">REGISTRATION CLOSED</h1><p className="muted">Энэ тэмцээний бүртгэл хаалттай байна.</p><Link className="btn-secondary" href={`/tournaments/${params.id}`}>Тэмцээн рүү буцах</Link></div></main>;
  return <main className="shell" style={{padding:"30px 0 64px"}}>
    <Link href={`/tournaments/${params.id}`} className="navlink">← {tournament.title}</Link>
    <div className="panel" style={{maxWidth:720,margin:"26px auto 0",padding:"clamp(20px,4vw,34px)"}}>
      <div className="eyebrow">OFFICIAL TEAM ENTRY</div><h1 className="brand" style={{fontSize:40,margin:"8px 0"}}>REGISTER YOUR TEAM.</h1>
      <p className="muted" style={{lineHeight:1.7}}>Тэмцээн: <b style={{color:"#f4f1e8"}}>{tournament.title}</b>. Мэдээллээ зөв бөглөөд илгээнэ үү. Бүртгэл админы баталгаажуулалт хүлээнэ.</p>
      {searchParams?.error ? <div role="alert" className="panel" style={{padding:13,borderColor:"#805b34",margin:"16px 0",color:"#f2d58b"}}>{({
        "missing-fields":"Бүх шаардлагатай талбарыг бөглөнө үү.",
        "tag-exists":"Энэ tag ашиглагдсан байна. Өөр tag сонгоно уу.",
        "registration-closed":"Бүртгэл хаалттай эсвэл slot дүүрсэн байна.",
        "submit-failed":"Бүртгэл илгээхэд алдаа гарлаа. Мэдээллээ шалгаад дахин оролдоно уу."
      } as Record<string,string>)[searchParams.error] ?? "Бүртгэл илгээхэд алдаа гарлаа."}</div> : null}
      <form action={submitTeamRegistration}>
        <input type="hidden" name="tournament_id" value={tournament.id}/>
        <label className="field">Багийн нэр / Team name<input name="team_name" required maxLength={80} placeholder="L¹91 eSport"/></label>
        <label className="field">Багийн tag<input name="team_tag" required maxLength={20} placeholder="L¹91"/></label>
        <label className="field">Ахлагчийн тоглоомын ID / Captain game ID<input name="captain_game_id" required maxLength={50} placeholder="Player ID"/></label>
        <div style={{borderTop:"1px solid #2c2d31",margin:"22px 0 10px",paddingTop:18}}><div className="eyebrow">PLAYER ROSTER / 4 ТОГЛОГЧ</div></div>
        {[1,2,3,4].map((n)=><div key={n} style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
          <label className="field">Player {n} — name<input name={`player_${n}_name`} required maxLength={60} placeholder={`Player ${n} name`}/></label>
          <label className="field">Player {n} — ID<input name={`player_${n}_id`} required maxLength={50} placeholder="In-game ID"/></label>
        </div>)}
        <label className="field">Нэмэлт мэдээлэл / Notes<textarea name="notes" maxLength={1000} rows={3} placeholder="Discord ID, manager details, etc."/></label>
        <button type="submit" className="btn" style={{width:"100%",marginTop:8}}>Бүртгэл илгээх / Submit registration</button>
        <p className="muted" style={{fontSize:11,lineHeight:1.6}}>Илгээснээр таны бүртгэл админы шалгалтад очно. Баталгаажаагүй бүртгэл slot-ийг эцэслэн батлахгүй.</p>
      </form>
    </div>
  </main>;
}
