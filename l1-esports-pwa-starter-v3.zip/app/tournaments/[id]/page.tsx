import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

function Countdown({ target }: { target: string | null }) {
  if (!target) return <span className="muted">Цаг удахгүй зарлагдана / Time TBA</span>;
  // A live countdown is hydrated by the browser on the client component in the next iteration.
  const date = new Date(target);
  return <span>{date.toLocaleString("en-GB",{dateStyle:"full",timeStyle:"short"})}</span>;
}

export default async function TournamentDetail({ params }: { params: { id: string } }) {
  const supabase = await createClient();
  const { data: t, error } = await supabase.from("tournaments").select("*").eq("id",params.id).maybeSingle();
  if (error || !t) notFound();
  const { data: matches } = await supabase.from("matches").select("id,round_number,match_number,team_a,team_b,score_a,score_b,status,winner_team_id").eq("tournament_id",t.id).order("round_number").order("match_number");
  const close = t.registration_closes_at ? new Date(t.registration_closes_at) : null;
  const start = t.start_at ? new Date(t.start_at) : null;
  const registrationOpen = t.status === "registration" && (!close || close.getTime() > Date.now()) && t.slots_filled < t.slots_total;
  const roundNames: Record<number,string> = {1:"Round 1",2:"Quarter Final",3:"Semi Final",4:"Grand Final"};
  return <main className="shell" style={{padding:"28px 0 64px"}}>
    <Link href="/tournaments" className="navlink">← Бүх тэмцээн / All tournaments</Link>
    <section className="panel" style={{padding:"clamp(20px,4vw,38px)",marginTop:24,position:"relative",overflow:"hidden"}}>
      <div style={{position:"absolute",right:-60,top:-75,width:230,height:230,border:"1px solid #584520",borderRadius:"50%"}}/>
      <div className="eyebrow">{t.game} · OFFICIAL TOURNAMENT</div>
      <h1 className="brand" style={{fontSize:"clamp(2.5rem,7vw,4.8rem)",lineHeight:1,margin:"14px 0"}}>{t.title}</h1>
      {t.title_en && <p className="muted">{t.title_en}</p>}
      <p className="muted" style={{maxWidth:700,lineHeight:1.8}}>{t.description || "Тэмцээний дэлгэрэнгүй мэдээлэл удахгүй нийтлэгдэнэ."}</p>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))",gap:10,marginTop:25}}>
        {[
          ["STATUS",t.status.toUpperCase()],
          ["FORMAT",t.format],
          ["GAME MODE",t.mode],
          ["TEAM SLOTS",`${t.slots_filled}/${t.slots_total}`]
        ].map(([label,value])=><div key={label} style={{background:"#090a0c",border:"1px solid #2c2d31",borderRadius:11,padding:14}}><div className="eyebrow" style={{fontSize:10}}>{label}</div><div style={{fontWeight:800,marginTop:8}}>{value}</div></div>)}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))",gap:12,marginTop:14}}>
        <div className="panel" style={{padding:16}}><div className="eyebrow">REGISTRATION CLOSES</div><div style={{marginTop:8,fontWeight:700}}><Countdown target={t.registration_closes_at}/></div></div>
        <div className="panel" style={{padding:16}}><div className="eyebrow">TOURNAMENT START</div><div style={{marginTop:8,fontWeight:700}}><Countdown target={t.start_at}/></div></div>
      </div>
      <div style={{marginTop:22,display:"flex",gap:12,flexWrap:"wrap"}}>
        {registrationOpen ? <Link className="btn" href={`/tournaments/${t.id}/register`}>Баг бүртгүүлэх / Register team →</Link> : <span className="btn-secondary" style={{opacity:.75}}>{t.status === "completed" ? "Тэмцээн дууссан / Completed" : "Бүртгэл хаалттай / Registration closed"}</span>}
        <Link className="btn-secondary" href="#bracket">Bracket & Results</Link>
      </div>
    </section>
    <section id="bracket" style={{marginTop:34}}>
      <div className="eyebrow">MATCH CENTER</div><h2 className="brand" style={{fontSize:34,margin:"8px 0 18px"}}>BRACKET <span className="gold">/ ТОГЛОЛТЫН ХҮСНЭГТ</span></h2>
      {!matches?.length ? <div className="panel" style={{padding:20}}><p className="muted" style={{margin:0}}>Тоглолтын хүснэгт хараахан үүсээгүй байна. / Bracket has not been generated yet.</p></div> :
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(min(100%,240px),1fr))",gap:12}}>
          {matches.map((m:any)=><div key={m.id} className="panel" style={{padding:16}}>
            <div className="eyebrow">{roundNames[m.round_number] ?? `Round ${m.round_number}`} · Match {m.match_number}</div>
            <div style={{display:"flex",justifyContent:"space-between",padding:"13px 0 9px",gap:10,borderBottom:"1px solid #292a2e"}}><span>{m.team_a ?? "TBD"}</span><b>{m.score_a ?? "—"}</b></div>
            <div style={{display:"flex",justifyContent:"space-between",padding:"10px 0",gap:10}}><span>{m.team_b ?? "TBD"}</span><b>{m.score_b ?? "—"}</b></div>
            <div className="muted" style={{fontSize:11}}>{m.status.toUpperCase()}</div>
          </div>)}
        </div>}
    </section>
  </main>;
}
