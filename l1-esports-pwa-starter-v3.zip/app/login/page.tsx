import { login, signup } from "./actions";
import Link from "next/link";

export default function LoginPage() {
  return <main className="shell" style={{padding:"48px 0"}}>
    <Link href="/" className="navlink">← L¹ Esports home</Link>
    <div style={{maxWidth:480,margin:"34px auto"}} className="panel">
      <div style={{padding:26}}>
        <div className="eyebrow">PLAYER & ADMIN ACCESS</div>
        <h1 className="brand" style={{fontSize:38,margin:"10px 0"}}>WELCOME BACK.</h1>
        <p className="muted" style={{lineHeight:1.6}}>Нэвтрэх эсвэл шинэ хэрэглэгчийн бүртгэл үүсгэнэ үү. Admin эрхийг зөвхөн database дээр эрх олгосон хэрэглэгч авна.</p>
        <form action={login}>
          <label className="field">Email<input name="email" type="email" required autoComplete="email" placeholder="you@example.com"/></label>
          <label className="field">Password<input name="password" type="password" required minLength={8} autoComplete="current-password" placeholder="At least 8 characters"/></label>
          <button className="btn" style={{width:"100%",marginTop:8}} type="submit">Нэвтрэх / Sign in</button>
        </form>
        <div style={{height:1,background:"#2c2d31",margin:"22px 0"}}/>
        <form action={signup}>
          <label className="field">Create account — Email<input name="email" type="email" required autoComplete="email" placeholder="you@example.com"/></label>
          <label className="field">Create password<input name="password" type="password" required minLength={8} autoComplete="new-password" placeholder="At least 8 characters"/></label>
          <button className="btn-secondary" style={{width:"100%"}} type="submit">Бүртгүүлэх / Create account</button>
        </form>
      </div>
    </div>
  </main>;
}
