-- L¹ Esports initial database schema for Supabase PostgreSQL.
-- Run in Supabase SQL Editor. RLS is enabled for all application tables.

create extension if not exists pgcrypto;

create type public.app_role as enum ('player', 'organizer', 'admin', 'super_admin');
create type public.tournament_status as enum ('draft', 'registration', 'locked', 'live', 'completed', 'cancelled');
create type public.registration_status as enum ('pending', 'approved', 'rejected', 'withdrawn');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role public.app_role not null default 'player',
  locale text not null default 'mn' check (locale in ('mn','en')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.tournaments (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  title_en text,
  description text,
  description_en text,
  game text not null default 'PUBG MOBILE',
  mode text not null default 'WOW 4v4',
  format text not null default 'BO3',
  bracket_type text not null default 'single_elimination',
  status public.tournament_status not null default 'draft',
  slots_total integer not null default 16 check (slots_total between 2 and 256),
  slots_filled integer not null default 0 check (slots_filled >= 0 and slots_filled <= slots_total),
  registration_opens_at timestamptz,
  registration_closes_at timestamptz,
  start_at timestamptz,
  created_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.teams (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  tag text not null,
  logo_url text,
  captain_id uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  unique (tag)
);

create table public.team_memberships (
  id uuid primary key default gen_random_uuid(),
  team_id uuid not null references public.teams(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  member_role text not null default 'player' check (member_role in ('captain','player','manager')),
  created_at timestamptz not null default now(),
  unique(team_id, user_id)
);

create table public.registrations (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete cascade,
  team_id uuid not null references public.teams(id) on delete cascade,
  status public.registration_status not null default 'pending',
  submitted_by uuid not null references public.profiles(id),
  reviewed_by uuid references public.profiles(id),
  review_note text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  unique(tournament_id, team_id)
);

create table public.matches (
  id uuid primary key default gen_random_uuid(),
  tournament_id uuid not null references public.tournaments(id) on delete cascade,
  round_number integer not null check (round_number > 0),
  match_number integer not null check (match_number > 0),
  team_a uuid references public.teams(id),
  team_b uuid references public.teams(id),
  score_a integer,
  score_b integer,
  winner_team_id uuid references public.teams(id),
  scheduled_at timestamptz,
  status text not null default 'pending' check (status in ('pending','live','completed','disputed')),
  result_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(tournament_id, round_number, match_number)
);

create table public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  title_en text,
  body text not null,
  body_en text,
  published boolean not null default false,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create index tournaments_status_start_idx on public.tournaments(status, start_at);
create index registrations_tournament_status_idx on public.registrations(tournament_id, status);
create index matches_tournament_round_idx on public.matches(tournament_id, round_number, match_number);

-- Create profile on sign-up. New accounts always start as player; never self-assign admin.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'display_name', split_part(new.email, '@', 1)));
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.has_staff_role()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid())
      and role in ('organizer','admin','super_admin')
  );
$$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid())
      and role in ('admin','super_admin')
  );
$$;

alter table public.profiles enable row level security;
alter table public.tournaments enable row level security;
alter table public.teams enable row level security;
alter table public.team_memberships enable row level security;
alter table public.registrations enable row level security;
alter table public.matches enable row level security;
alter table public.announcements enable row level security;

create policy "Profiles are visible to signed-in users" on public.profiles
for select to authenticated using (true);
create policy "Users update own non-role profile fields" on public.profiles
for update to authenticated using (id = (select auth.uid()))
with check (id = (select auth.uid()) and role = (select role from public.profiles p where p.id = (select auth.uid())));

create policy "Published tournaments visible publicly" on public.tournaments
for select to anon, authenticated using (status in ('registration','locked','live','completed') or public.has_staff_role());
create policy "Staff create tournaments" on public.tournaments
for insert to authenticated with check (public.has_staff_role() and created_by = (select auth.uid()));
create policy "Staff update tournaments" on public.tournaments
for update to authenticated using (public.has_staff_role()) with check (public.has_staff_role());
create policy "Admins delete tournaments" on public.tournaments
for delete to authenticated using (public.is_admin());

create policy "Teams visible to everyone" on public.teams
for select to anon, authenticated using (true);
create policy "Signed-in users create teams as captain" on public.teams
for insert to authenticated with check (captain_id = (select auth.uid()));
create policy "Captain or staff updates team" on public.teams
for update to authenticated using (captain_id = (select auth.uid()) or public.has_staff_role())
with check (captain_id = (select auth.uid()) or public.has_staff_role());
create policy "Captain or admin deletes team" on public.teams
for delete to authenticated using (captain_id = (select auth.uid()) or public.is_admin());

create policy "Memberships visible to signed-in users" on public.team_memberships
for select to authenticated using (user_id = (select auth.uid()) or public.has_staff_role());
create policy "Captain or staff adds memberships" on public.team_memberships
for insert to authenticated with check (
  user_id = (select auth.uid()) or public.has_staff_role() or
  exists (select 1 from public.teams t where t.id = team_id and t.captain_id = (select auth.uid()))
);
create policy "Staff or self removes membership" on public.team_memberships
for delete to authenticated using (user_id = (select auth.uid()) or public.has_staff_role());

create policy "Registrations visible to submitting team and staff" on public.registrations
for select to authenticated using (
  submitted_by = (select auth.uid()) or public.has_staff_role() or
  exists (select 1 from public.teams t where t.id = team_id and t.captain_id = (select auth.uid()))
);
create policy "Captain submits registration" on public.registrations
for insert to authenticated with check (
  submitted_by = (select auth.uid()) and
  exists (select 1 from public.teams t where t.id = team_id and t.captain_id = (select auth.uid()))
);
create policy "Staff reviews registrations" on public.registrations
for update to authenticated using (public.has_staff_role()) with check (public.has_staff_role());
create policy "Admins remove registrations" on public.registrations
for delete to authenticated using (public.is_admin());

create policy "Match results visible publicly for published tournaments" on public.matches
for select to anon, authenticated using (
  exists (select 1 from public.tournaments t where t.id = tournament_id and
  (t.status in ('registration','locked','live','completed') or public.has_staff_role()))
);
create policy "Staff manages matches" on public.matches
for insert to authenticated with check (public.has_staff_role());
create policy "Staff updates matches" on public.matches
for update to authenticated using (public.has_staff_role()) with check (public.has_staff_role());
create policy "Admins delete matches" on public.matches
for delete to authenticated using (public.is_admin());

create policy "Published announcements visible publicly" on public.announcements
for select to anon, authenticated using (published or public.has_staff_role());
create policy "Staff creates announcements" on public.announcements
for insert to authenticated with check (public.has_staff_role() and created_by = (select auth.uid()));
create policy "Staff updates announcements" on public.announcements
for update to authenticated using (public.has_staff_role()) with check (public.has_staff_role());
create policy "Admins delete announcements" on public.announcements
for delete to authenticated using (public.is_admin());

-- After signing up with your own account, run this separately to grant initial super-admin:
-- update public.profiles set role = 'super_admin' where id = 'YOUR_AUTH_USER_UUID';
