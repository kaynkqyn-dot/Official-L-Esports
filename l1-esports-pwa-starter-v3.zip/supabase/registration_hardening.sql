-- L¹ Esports registration hardening migration (apply after schema.sql)
-- Run once in Supabase SQL Editor. Existing registrations remain intact.

alter table public.teams add column if not exists captain_game_id text;
alter table public.registrations add column if not exists applicant_note text;

create table if not exists public.registration_players (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid not null references public.registrations(id) on delete cascade,
  player_number integer not null check (player_number between 1 and 4),
  player_name text not null check (length(trim(player_name)) between 1 and 60),
  game_id text not null check (length(trim(game_id)) between 1 and 50),
  created_at timestamptz not null default now(),
  unique (registration_id, player_number)
);

create index if not exists registration_players_registration_idx
  on public.registration_players(registration_id, player_number);

alter table public.registration_players enable row level security;

drop policy if exists "Roster visible to submitting captain and staff" on public.registration_players;
create policy "Roster visible to submitting captain and staff"
on public.registration_players for select to authenticated
using (
  public.has_staff_role() or exists (
    select 1
    from public.registrations r
    join public.teams t on t.id = r.team_id
    where r.id = registration_id
      and (r.submitted_by = (select auth.uid()) or t.captain_id = (select auth.uid()))
  )
);

-- Serializes approvals per tournament and prevents approving more teams than slots.
create or replace function public.guard_registration_capacity()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_slots integer;
  v_status public.registration_status;
  v_count integer;
  v_tournament_id uuid;
begin
  v_tournament_id := coalesce(new.tournament_id, old.tournament_id);

  if tg_op = 'UPDATE' and old.status = 'approved' and new.status = 'approved' then
    return new;
  end if;

  if tg_op = 'DELETE' then
    return old;
  end if;

  if new.status = 'approved' then
    select slots_total into v_slots
    from public.tournaments
    where id = new.tournament_id
    for update;

    if not found then
      raise exception 'Tournament not found';
    end if;

    select count(*) into v_count
    from public.registrations
    where tournament_id = new.tournament_id
      and status = 'approved'
      and id <> new.id;

    if v_count >= v_slots then
      raise exception 'No available team slots remain for this tournament';
    end if;
  end if;
  return new;
end;
$$;

drop trigger if exists registrations_capacity_guard on public.registrations;
create trigger registrations_capacity_guard
before insert or update of status, tournament_id on public.registrations
for each row execute function public.guard_registration_capacity();

-- Keep the denormalized counter accurate; slots_filled counts approved registrations only.
create or replace function public.refresh_tournament_slots_filled()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_tournament_id uuid;
begin
  if tg_op = 'DELETE' then
    v_tournament_id := old.tournament_id;
  else
    v_tournament_id := new.tournament_id;
  end if;

  update public.tournaments t
  set slots_filled = (
    select count(*)::integer
    from public.registrations r
    where r.tournament_id = v_tournament_id and r.status = 'approved'
  ),
  updated_at = now()
  where t.id = v_tournament_id;

  if tg_op = 'UPDATE' and old.tournament_id is distinct from new.tournament_id then
    update public.tournaments t
    set slots_filled = (
      select count(*)::integer from public.registrations r
      where r.tournament_id = old.tournament_id and r.status = 'approved'
    ),
    updated_at = now()
    where t.id = old.tournament_id;
  end if;

  if tg_op = 'DELETE' then return old; else return new; end if;
end;
$$;

drop trigger if exists registrations_refresh_slots on public.registrations;
create trigger registrations_refresh_slots
after insert or update of status, tournament_id or delete on public.registrations
for each row execute function public.refresh_tournament_slots_filled();

-- One transaction: validates event capacity and creates the team, captain membership,
-- registration and all four roster entries together, or creates none of them.
create or replace function public.submit_team_registration(
  p_tournament_id uuid,
  p_team_name text,
  p_team_tag text,
  p_captain_game_id text,
  p_roster jsonb,
  p_notes text default null
)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user_id uuid;
  v_tournament public.tournaments%rowtype;
  v_team_id uuid;
  v_registration_id uuid;
  v_item jsonb;
  v_num integer := 0;
  v_name text;
  v_game_id text;
begin
  v_user_id := auth.uid();
  if v_user_id is null then raise exception 'You must sign in before registering'; end if;

  if length(trim(coalesce(p_team_name,''))) not between 1 and 80 then
    raise exception 'Team name must be between 1 and 80 characters';
  end if;
  if length(trim(coalesce(p_team_tag,''))) not between 1 and 20 then
    raise exception 'Team tag must be between 1 and 20 characters';
  end if;
  if length(trim(coalesce(p_captain_game_id,''))) not between 1 and 50 then
    raise exception 'Captain game ID is required';
  end if;
  if jsonb_typeof(p_roster) <> 'array' or jsonb_array_length(p_roster) <> 4 then
    raise exception 'Exactly four players are required';
  end if;
  if length(coalesce(p_notes,'')) > 1000 then raise exception 'Notes are too long'; end if;

  -- Lock the tournament row so simultaneous submissions cannot exceed available slots.
  select * into v_tournament
  from public.tournaments
  where id = p_tournament_id
  for update;

  if not found then raise exception 'Tournament not found'; end if;
  if v_tournament.status <> 'registration' then raise exception 'Registration is not open'; end if;
  if v_tournament.registration_closes_at is not null and v_tournament.registration_closes_at <= now() then
    raise exception 'Registration deadline has passed';
  end if;
  if v_tournament.slots_filled >= v_tournament.slots_total then
    raise exception 'All team slots are full';
  end if;

  if exists (
    select 1 from public.registrations r
    join public.teams t on t.id = r.team_id
    where r.tournament_id = p_tournament_id
      and r.submitted_by = v_user_id
      and r.status in ('pending','approved')
  ) then raise exception 'You already have a team registered for this tournament'; end if;

  insert into public.teams(name,tag,captain_id,captain_game_id)
  values(trim(p_team_name),trim(p_team_tag),v_user_id,trim(p_captain_game_id))
  returning id into v_team_id;

  insert into public.team_memberships(team_id,user_id,member_role)
  values(v_team_id,v_user_id,'captain');

  insert into public.registrations(tournament_id,team_id,submitted_by,status,applicant_note)
  values(p_tournament_id,v_team_id,v_user_id,'pending',nullif(trim(coalesce(p_notes,'')),''))
  returning id into v_registration_id;

  for v_item in select value from jsonb_array_elements(p_roster)
  loop
    v_num := v_num + 1;
    v_name := trim(coalesce(v_item ->> 'name',''));
    v_game_id := trim(coalesce(v_item ->> 'game_id',''));
    if length(v_name) not between 1 and 60 or length(v_game_id) not between 1 and 50 then
      raise exception 'Each player needs a valid name and game ID';
    end if;
    insert into public.registration_players(registration_id,player_number,player_name,game_id)
    values(v_registration_id,v_num,v_name,v_game_id);
  end loop;

  return v_registration_id;
exception
  when unique_violation then
    raise exception 'That team tag is already in use. Please choose another tag.';
end;
$$;

revoke all on function public.submit_team_registration(uuid,text,text,text,jsonb,text) from public;
grant execute on function public.submit_team_registration(uuid,text,text,text,jsonb,text) to authenticated;

-- Existing counts are reconciled after adding the trigger.
update public.tournaments t
set slots_filled = (
  select count(*)::integer from public.registrations r
  where r.tournament_id = t.id and r.status = 'approved'
);
